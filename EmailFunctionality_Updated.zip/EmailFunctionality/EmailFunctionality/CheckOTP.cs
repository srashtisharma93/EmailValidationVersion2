﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace EmailFunctionality
{
    class CheckOTP
    {
        /// <summary>
        /// Check OTP and compare User input OTP with the OTP from database
        /// </summary>
        /// <param name="input">user input OTP</param>
        /// <returns>Status result for OTP check</returns>
        public static string check_OTP(iostream input)
        {
            string output = string.Empty;
            try
            {
                int inputOTP = input.readOTP();
                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                for (int i = 0; i <= 10; i++)
                {
                    if (stopwatch.Elapsed > TimeSpan.FromMinutes(1))
                    {
                        output = "STATUS_OTP_TIMEOUT: timeout after 1 min";
                        return output;
                    }
                    else
                    {
                        int GeneratedOTP = 110001; // Get OTP from database using email address
                        //Compare logic-
                        //Insert Email address and OTP in database with relevant info to database table
                        //Every time the OTP is updated (older OTP is replaced by new OTP) OR can retrieve latest OTP 
                        //for the email address based on the latest date.
                        if (compareOTP(inputOTP, GeneratedOTP))
                        {
                            output = "STATUS_OTP_OK: OTP is valid and checked";
                            return output;
                        }
                        if (i == 10)
                            return "STATUS_OTP_FAIL: OTP is wrong after 10 tries";
                    }
                }
            }
            catch (Exception ex)
            {
                output = ex.Message;
            }
            return output;
        }

        private static bool compareOTP(int userOTP, int generatedOTP)
        {
            throw new NotImplementedException();
        }
    }
}
