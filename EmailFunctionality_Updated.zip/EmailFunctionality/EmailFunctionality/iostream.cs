﻿using System;

namespace EmailFunctionality
{
    internal class iostream
    {
        internal int readOTP()
        {
            throw new NotImplementedException();
        }
        internal object input()
        {
            throw new NotImplementedException();
        }
    }
}